﻿function udfRegEx(input, regex) {
	return input.match(regex);
}
